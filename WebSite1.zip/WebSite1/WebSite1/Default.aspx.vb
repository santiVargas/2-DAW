﻿Imports System.Data.SqlClient

Partial Class _Default
    Inherits System.Web.UI.Page

    Private Sub _Default_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Dim cnnt As New SqlConnection

        'Dim conexion As String = "Data Source = (local);Initial Catalog = Bankline;Integrated Security = SSPI"

        'cnnt.ConnectionString = conexion
        'cnnt.Open()

        'If cnnt.State = Data.ConnectionState.Open Then
        '    Response.Write("conexion establecida")
        'End If

        Response.Write(sqlComponente.ejecutar(sqlComponente.Conectar("(local)", "Bankline"), "update clientes set cpostal = ''"))
    End Sub
End Class