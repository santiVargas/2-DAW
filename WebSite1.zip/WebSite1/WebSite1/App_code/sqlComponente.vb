﻿Imports System.Data.SqlClient


Public Class sqlComponente
    Public Shared Function Conectar(ByVal servidor As String, base As String, Optional ByVal usuario As String = Nothing, Optional ByVal password As String = Nothing) As SqlConnection
        Dim cnnt As New SqlConnection

        If usuario <> Nothing And password <> Nothing Then
			cnnt.ConnectionString = "Data Source=" & servidor & ";Initial Catalog=" & base & ";User ID=" & usuario & ";Password=" & password
        Else
            cnnt.ConnectionString = "Data Source=" & servidor & ";Initial Catalog=" & base & ";Integrated Security=SSPI"
        End If
        Try
            cnnt.Open()

        Catch
            cnnt = Nothing
        End Try

        Return cnnt

    End Function
    Public Shared Function ejecutar(ByVal conexion As SqlConnection, sentencia As String) As Integer
        Dim n As Integer
        Dim cmd As New SqlCommand(sentencia, conexion)
        'cmd.CommandType = Data.CommandType.Text
        'cmd.CommandText = sentencia
        'cmd.Connection = conexion
        Try
            n = cmd.ExecuteNonQuery()
        Catch ex As Exception
            n = -1
        End Try
        Return n

    End Function

End Class
